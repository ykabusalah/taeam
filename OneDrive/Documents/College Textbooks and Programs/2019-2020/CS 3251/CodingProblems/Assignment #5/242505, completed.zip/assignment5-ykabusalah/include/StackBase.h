// @author G. Hemingway, copyright 2018 - All rights reserved
//
#ifndef STACK_BASE_H
#define STACK_BASE_H

#include <cstdint>

/**
 * An abstract base class for classes implementing the Stack ADT. This class
 * defines the classical interface for stacks.
 */
template <typename T> class StackBase {
public:
    /**
     * Default virtual destructor.
     */
    virtual ~StackBase() = default;

    /**
     * Returns true if this stack is empty.
     *
     * @return bool - true if stack is empty
     */
    bool isEmpty() const noexcept;

    /**
     * Removes the top element from the stack. Should throw std::underflow_error if this stack
     * is empty.
     */
    virtual void pop() = 0;

    /**
     * Adds value to the top of the stack.
     *
     * @param value new value to push onto stack
     */
    virtual void push(const T& value) = 0;

    /**
     * Returns the size of this stack.
     *
     * @return number of elements in the stack
     */
    virtual uint32_t size() const noexcept = 0;

    /**
     * Returns a reference to the top of the stack. Should throw std::underflow_error if this
     * stack is empty.
     *
     * @return value of element at top of stack
     */
    virtual const T& top() const = 0;

    /**
     * Returns a reference to the top of the stack. Throws std::underflow_error if this
     * stack is empty.
     *
     * @return value at top of stack
     */
    T& top();
};

#include "../src/StackBase.cpp"

#endif // STACK_BASE_H
